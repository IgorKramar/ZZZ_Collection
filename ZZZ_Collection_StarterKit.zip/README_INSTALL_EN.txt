===============================================================
  ZZZ INDUSTRIAL COLLECTION — INSTALL & SETUP
  for Project Zomboid Build 42.20.2+
===============================================================

Collection: https://steamcommunity.com/sharedfiles/filedetails/?id=3778214259

This kit contains what a Steam subscription does NOT deliver
automatically: a tuned mod load order and a ready-to-use list of
enabled mods. Plus answers to the questions that will come up on
your first launch.


---------------------------------------------------------------
STEP 1. Switch to Build 42
---------------------------------------------------------------
Steam -> Library -> Project Zomboid -> Properties -> Betas ->
select the b42 branch. The pack is tested on version 42.20.2.

---------------------------------------------------------------
STEP 2. Subscribe to the collection
---------------------------------------------------------------
Open the collection page (link above) and press
"Subscribe to all". Wait until Steam finishes downloading all the
mods (it is several gigabytes — check the Downloads page).

---------------------------------------------------------------
STEP 3. Enable the mods
---------------------------------------------------------------
Option A (recommended — a ready-made list in a single file):
  1. Close the game if it is running.
  2. Copy the file  Zomboid\mods\default.txt  from this archive
     into  C:\Users\<YOUR NAME>\Zomboid\mods\  replacing the
     existing one.
     WARNING: this overwrites your current enabled-mods list.
  3. Launch the game — all 100 mods of the pack come pre-enabled.

Option B (by hand):
  Launch the game -> MODS -> enable everything from the
  collection EXCEPT the items listed in "DO NOT ENABLE" below.

---------------------------------------------------------------
STEP 4. Load order
---------------------------------------------------------------
  1. Copy the file  Zomboid\Lua\sorting_rules.txt  from this
     archive into  C:\Users\<YOUR NAME>\Zomboid\Lua\ .
  2. On the MODS screen press the "SORT AND ACCEPT" button
     (the button is provided by the Mod Load Order Sorter mod from
     the collection — it reads these rules and arranges everything
     for you).

---------------------------------------------------------------
STEP 5. Map priorities (once, optional)
---------------------------------------------------------------
A few maps of the pack overlap at their edges. This is NOT an
error — Map Mod Manager (a tab on the mods screen) acts as the
referee:
  - Constown and New Hartburg contest cells 24_42-24_44;
  - Louisville Quarantine Zone and PIE42 contest cells 44_13
    and 45_13.
Pick in Map Mod Manager which map wins the contested cells — your
choice. The pack validator (ZZZ Mod Stitch) will keep reminding
you about these overlaps with a yellow warning — that is expected.

---------------------------------------------------------------
DO NOT ENABLE
---------------------------------------------------------------
  - Capacity Limit Bypass [MANUAL INSTALLATION] — the red row in
    the mod list. It is NOT a regular mod: it asks you to manually
    replace game engine files. For the sake of a stable pack, do
    NOT install it and do not try to enable it (the game will not
    let you anyway). You can hide the row with the "Hide" button.
  - Somewhat Traits Skills — a submod with faceless iconless
    "+1 skill" traits. Superseded by Legendary Professions and
    Traits, which does the same thing properly. In the Option A
    list it is already disabled.

---------------------------------------------------------------
FIRST LAUNCH: WHAT COUNTS AS NORMAL
---------------------------------------------------------------
  - Yellow warnings from the ZZZ Mod Stitch validator about map
    cell overlaps (see Step 5) and about tiledef 7001
    (Customizable Containers vs Fort Waterfront) — known quirks,
    no effect on gameplay.
  - After enabling Horse Mod, do a full game restart from the main
    menu before playing, or horses will appear as animation
    placeholder blobs.
  - Anything else shown in red by the validator is worth a post
    in the collection comments.

---------------------------------------------------------------
LANGUAGE
---------------------------------------------------------------
Russian switches on by itself when the game language is Russian:
the ZZZ RusPack mod fills the gaps (15,000+ strings on top of mods that ship without one or with an incomplete translation). Nothing to configure —
it just has to be enabled. With any other game language the pack
plays in English.

---------------------------------------------------------------
PROBLEMS?
---------------------------------------------------------------
Post in the discussions of the respective mod:
  Hydrocraft Reinvented:  https://steamcommunity.com/sharedfiles/filedetails/?id=3778201332
  ZZZ Mod Stitch:         https://steamcommunity.com/sharedfiles/filedetails/?id=3778211804
  ZZZ RusPack:            https://steamcommunity.com/sharedfiles/filedetails/?id=3778212091
or in the collection comments. Attach the tail of the console.txt
file from your Zomboid folder to any bug report.

Happy surviving!
                                          — hombrehumor
